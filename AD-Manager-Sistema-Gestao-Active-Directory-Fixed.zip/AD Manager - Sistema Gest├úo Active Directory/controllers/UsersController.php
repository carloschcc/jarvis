<?php
class UsersController {
    private $authModel;
    private $ldapModel;
    
    public function __construct() {
        $this->authModel = new AuthModel();
        $this->ldapModel = new LdapModel();
    }
    
    public function index() {
        if (!$this->authModel->isLoggedIn()) {
            header('Location: index.php?page=login');
            exit;
        }
        
        $currentUser = $this->authModel->getCurrentUser();
        $search = $_GET['search'] ?? '';
        $limit = (int)($_GET['limit'] ?? 50);
        
        // Coletar filtros avançados
        $filters = [
            'department' => $_GET['department'] ?? '',
            'city' => $_GET['city'] ?? '',
            'title' => $_GET['title'] ?? '',
            'company' => $_GET['company'] ?? '',
            'office' => $_GET['office'] ?? '',
            'manager' => $_GET['manager'] ?? '',
            'status' => $_GET['status'] ?? ''
        ];
        
        // Remover filtros vazios
        $filters = array_filter($filters, function($value) {
            return !empty($value) && $value !== 'all';
        });
        
        try {
            // Buscar usuários do LDAP com filtros
            $users = $this->ldapModel->getUsers($search, $limit, $filters);
            
            // Obter listas para os filtros dropdowns
            $departments = $this->ldapModel->getDepartments();
            $cities = $this->ldapModel->getCities();
            $companies = $this->ldapModel->getCompanies();
            $titles = $this->ldapModel->getTitles();
            $offices = $this->ldapModel->getOffices();
            
            logMessage('INFO', 'Carregados ' . count($users) . ' usuários do LDAP com filtros aplicados');
            
        } catch (Exception $e) {
            logMessage('ERROR', 'Erro ao carregar usuários: ' . $e->getMessage());
            $users = [];
            // Valores padrão para fallback
            $departments = ['TI', 'RH', 'Vendas', 'Financeiro', 'Marketing'];
            $cities = ['São Paulo', 'Rio de Janeiro', 'Belo Horizonte', 'Brasília'];
            $companies = ['Empresa Principal', 'Filial SP', 'Filial RJ'];
            $titles = ['Analista', 'Desenvolvedor', 'Gerente', 'Diretor', 'Coordenador'];
            $offices = ['Escritório Central', 'Sede São Paulo', 'Filial Rio de Janeiro'];
        }
        
        $data = [
            'title' => 'Usuários - ' . APP_NAME,
            'current_user' => $currentUser,
            'users' => $users,
            'search' => $search,
            'limit' => $limit,
            'filters' => $filters,
            'departments' => $departments,
            'cities' => $cities,
            'companies' => $companies,
            'titles' => $titles,
            'offices' => $offices,
            'total_users' => count($users),
            'csrf_token' => generateCSRFToken()
        ];
        
        $this->loadView('users/index', $data);
    }
    
    public function search() {
        header('Content-Type: application/json');
        
        if (!$this->authModel->isLoggedIn()) {
            echo json_encode(['success' => false, 'message' => 'Não autenticado']);
            exit;
        }
        
        $search = $_GET['q'] ?? '';
        $limit = (int)($_GET['limit'] ?? 20);
        
        // Coletar filtros avançados
        $filters = [
            'department' => $_GET['department'] ?? '',
            'city' => $_GET['city'] ?? '',
            'title' => $_GET['title'] ?? '',
            'company' => $_GET['company'] ?? '',
            'office' => $_GET['office'] ?? '',
            'manager' => $_GET['manager'] ?? '',
            'status' => $_GET['status'] ?? ''
        ];
        
        // Remover filtros vazios
        $filters = array_filter($filters, function($value) {
            return !empty($value) && $value !== 'all';
        });
        
        try {
            $users = $this->ldapModel->getUsers($search, $limit, $filters);
            
            logMessage('INFO', 'Busca realizada: "' . $search . '" com filtros - ' . count($users) . ' resultados');
            
            echo json_encode([
                'success' => true,
                'users' => $users,
                'total' => count($users),
                'filters_applied' => $filters
            ]);
            
        } catch (Exception $e) {
            logMessage('ERROR', 'Erro na busca de usuários: ' . $e->getMessage());
            
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao buscar usuários: ' . $e->getMessage()
            ]);
        }
    }
    
    public function toggleStatus() {
        header('Content-Type: application/json');
        
        if (!$this->authModel->isLoggedIn() || !$this->authModel->isAdmin()) {
            echo json_encode(['success' => false, 'message' => 'Acesso negado']);
            exit;
        }
        
        if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
            echo json_encode(['success' => false, 'message' => 'Token CSRF inválido']);
            exit;
        }
        
        $username = $_POST['username'] ?? '';
        $enable = ($_POST['action'] ?? '') === 'enable';
        
        if (empty($username)) {
            echo json_encode(['success' => false, 'message' => 'Nome de usuário não informado']);
            exit;
        }
        
        try {
            $result = $this->ldapModel->toggleUserStatus($username, $enable);
            
            logMessage('INFO', "Status do usuário {$username} alterado por {$this->authModel->getCurrentUser()['username']}");
            
            echo json_encode($result);
            
        } catch (Exception $e) {
            logMessage('ERROR', 'Erro ao alterar status do usuário: ' . $e->getMessage());
            
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao alterar status: ' . $e->getMessage()
            ]);
        }
    }
    
    public function resetPassword() {
        header('Content-Type: application/json');
        
        if (!$this->authModel->isLoggedIn() || !$this->authModel->isAdmin()) {
            echo json_encode(['success' => false, 'message' => 'Acesso negado']);
            exit;
        }
        
        if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
            echo json_encode(['success' => false, 'message' => 'Token CSRF inválido']);
            exit;
        }
        
        $username = $_POST['username'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        
        if (empty($username) || empty($newPassword)) {
            echo json_encode(['success' => false, 'message' => 'Dados incompletos']);
            exit;
        }
        
        // Validar força da senha
        if (strlen($newPassword) < 8) {
            echo json_encode(['success' => false, 'message' => 'Senha deve ter pelo menos 8 caracteres']);
            exit;
        }
        
        try {
            $result = $this->ldapModel->resetPassword($username, $newPassword);
            
            logMessage('INFO', "Senha resetada para usuário {$username} por {$this->authModel->getCurrentUser()['username']}");
            
            echo json_encode($result);
            
        } catch (Exception $e) {
            logMessage('ERROR', 'Erro ao resetar senha: ' . $e->getMessage());
            
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao resetar senha: ' . $e->getMessage()
            ]);
        }
    }
    
    public function getUser() {
        header('Content-Type: application/json');
        
        if (!$this->authModel->isLoggedIn()) {
            echo json_encode(['success' => false, 'message' => 'Não autenticado']);
            exit;
        }
        
        $username = $_GET['username'] ?? '';
        
        if (empty($username)) {
            echo json_encode(['success' => false, 'message' => 'Nome de usuário não informado']);
            exit;
        }
        
        try {
            $user = $this->ldapModel->getUser($username);
            
            if (!$user) {
                echo json_encode(['success' => false, 'message' => 'Usuário não encontrado']);
            } else {
                echo json_encode(['success' => true, 'user' => $user]);
            }
            
        } catch (Exception $e) {
            logMessage('ERROR', 'Erro ao buscar usuário: ' . $e->getMessage());
            
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao buscar usuário: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Criar novo usuário
     */
    public function create() {
        header('Content-Type: application/json');
        
        if (!$this->authModel->isLoggedIn() || !$this->authModel->isAdmin()) {
            echo json_encode(['success' => false, 'message' => 'Acesso negado']);
            exit;
        }
        
        if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
            echo json_encode(['success' => false, 'message' => 'Token CSRF inválido']);
            exit;
        }
        
        $userData = [
            'username' => $_POST['username'] ?? '',
            'name' => $_POST['name'] ?? '',
            'email' => $_POST['email'] ?? '',
            'description' => $_POST['description'] ?? '',
            'phone' => $_POST['phone'] ?? '',
            'department' => $_POST['department'] ?? ''
        ];
        
        // Validações básicas
        if (empty($userData['username']) || empty($userData['name'])) {
            echo json_encode(['success' => false, 'message' => 'Nome de usuário e nome completo são obrigatórios']);
            exit;
        }
        
        try {
            $result = $this->ldapModel->createUser($userData);
            
            if ($result['success']) {
                logMessage('INFO', "Usuário {$userData['username']} criado por {$this->authModel->getCurrentUser()['username']}");
            }
            
            echo json_encode($result);
            
        } catch (Exception $e) {
            logMessage('ERROR', 'Erro ao criar usuário: ' . $e->getMessage());
            
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao criar usuário: ' . $e->getMessage()
            ]);
        }
    }
    
    /**
     * Obter listas para filtros (AJAX)
     */
    public function getFilterOptions() {
        header('Content-Type: application/json');
        
        if (!$this->authModel->isLoggedIn()) {
            echo json_encode(['success' => false, 'message' => 'Não autenticado']);
            exit;
        }
        
        try {
            $departments = $this->ldapModel->getDepartments();
            $cities = $this->ldapModel->getCities();
            $companies = $this->ldapModel->getCompanies();
            
            echo json_encode([
                'success' => true,
                'departments' => $departments,
                'cities' => $cities,
                'companies' => $companies,
                'status_options' => [
                    ['value' => 'all', 'label' => 'Todos os Status'],
                    ['value' => 'active', 'label' => 'Ativo'],
                    ['value' => 'disabled', 'label' => 'Bloqueado']
                ]
            ]);
            
        } catch (Exception $e) {
            logMessage('ERROR', 'Erro ao obter opções de filtro: ' . $e->getMessage());
            
            echo json_encode([
                'success' => false,
                'message' => 'Erro ao carregar filtros: ' . $e->getMessage()
            ]);
        }
    }
    
    private function loadView($view, $data = []) {
        extract($data);
        include VIEWS_PATH . '/' . $view . '.php';
    }
}